"""translate_ai 业务逻辑模块：文本提取、翻译、缓存、术语库、历史记录、导出"""

import json
import hashlib
import os
import io
import time
import base64
from datetime import datetime
from pathlib import Path
from io import BytesIO

from dashscope import Generation
import pdfplumber
import fitz  # PyMuPDF
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ============================================================
# 数据目录初始化
# ============================================================
DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)
RESULT_DIR = Path(__file__).parent / "result"
RESULT_DIR.mkdir(exist_ok=True)

GLOSSARY_FILE = DATA_DIR / "glossary.json"
CACHE_FILE = DATA_DIR / "translation_cache.json"
HISTORY_FILE = DATA_DIR / "translation_history.json"

# ============================================================
# 术语库管理
# ============================================================
def load_glossary():
    """加载术语库，返回 {source_term: target_term}"""
    if not GLOSSARY_FILE.exists():
        return {}
    with open(GLOSSARY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_glossary(glossary):
    """保存术语库到 JSON"""
    with open(GLOSSARY_FILE, "w", encoding="utf-8") as f:
        json.dump(glossary, f, ensure_ascii=False, indent=2)

def add_glossary_term(source, target):
    """添加一条术语对"""
    glossary = load_glossary()
    glossary[source.strip()] = target.strip()
    save_glossary(glossary)

def remove_glossary_term(source):
    """删除一条术语"""
    glossary = load_glossary()
    glossary.pop(source, None)
    save_glossary(glossary)

def get_glossary_prompt():
    """生成术语库提示词，注入到翻译 prompt 中"""
    glossary = load_glossary()
    if not glossary:
        return ""
    lines = ["\n【术语翻译对照表 - 请严格遵循以下术语翻译】"]
    for src, tgt in glossary.items():
        lines.append(f"- {src} → {tgt}")
    return "\n".join(lines) + "\n\n"

# ============================================================
# 文本提取：PDF / DOCX / TXT / MD
# ============================================================
def extract_text(uploaded_file, max_pages=50, force_ocr=False, ocr_lang="chi_sim+eng"):
    """统一文本提取入口，根据文件扩展名分发"""
    filename = uploaded_file.name.lower()
    uploaded_bytes = uploaded_file.read()

    if filename.endswith(".pdf"):
        return extract_pdf_text(uploaded_bytes, max_pages, force_ocr, ocr_lang)
    elif filename.endswith(".docx"):
        return extract_docx_text(uploaded_bytes)
    elif filename.endswith(".txt"):
        return extract_txt_text(uploaded_bytes)
    elif filename.endswith(".md"):
        return extract_md_text(uploaded_bytes)
    else:
        return ""

# ---- PDF ----
def extract_pdf_text(uploaded_bytes, max_pages=50, force_ocr=False, ocr_lang="chi_sim+eng"):
    """提取 PDF 文本，支持 OCR 回退。返回 (text, warning_msg)"""
    if force_ocr:
        return ocr_pdf_text(uploaded_bytes, max_pages, ocr_lang), ""

    try:
        text = ""
        with pdfplumber.open(io.BytesIO(uploaded_bytes)) as pdf:
            pages_to_process = min(max_pages, len(pdf.pages))
            for i in range(pages_to_process):
                page_text = pdf.pages[i].extract_text()
                if page_text:
                    text += f"\n--- 第 {i+1} 页 ---\n{page_text}\n"

        warning = ""
        if not text.strip() or len(text.strip()) < 50:
            warning = "⚠️ 提取到的文字很少，可能是扫描件，建议勾选「扫描件模式」"
        return text, warning
    except Exception as e:
        return "", f"PDF 读取错误: {str(e)}"

def ocr_pdf_text(uploaded_bytes, max_pages=50, ocr_lang="chi_sim+eng"):
    """OCR 识别扫描件 PDF"""
    try:
        from pdf2image import convert_from_bytes
        import pytesseract

        images = convert_from_bytes(uploaded_bytes, first_page=1, last_page=max_pages)
        text = ""
        for i, image in enumerate(images):
            page_text = pytesseract.image_to_string(image, lang=ocr_lang)
            if page_text.strip():
                text += f"\n--- 第 {i+1} 页 ---\n{page_text}\n"
        return text
    except ImportError as e:
        raise ImportError("OCR 需要安装 Tesseract: brew install tesseract tesseract-lang")
    except Exception as e:
        raise Exception(f"OCR 识别错误: {str(e)}")

# ---- DOCX ----
def extract_docx_text(uploaded_bytes):
    """提取 .docx 文件文本"""
    try:
        doc = Document(io.BytesIO(uploaded_bytes))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        return "\n\n".join(paragraphs), ""
    except Exception as e:
        return "", f"DOCX 读取错误: {str(e)}"

# ---- TXT ----
def extract_txt_text(uploaded_bytes):
    """提取 .txt 文件文本，自动检测编码"""
    for encoding in ["utf-8", "gbk", "gb2312", "latin-1"]:
        try:
            return uploaded_bytes.decode(encoding), ""
        except (UnicodeDecodeError, LookupError):
            continue
    return "", "TXT 文件编码无法识别"

# ---- MD ----
def extract_md_text(uploaded_bytes):
    """提取 .md 文件文本"""
    return extract_txt_text(uploaded_bytes)

# ============================================================
# 翻译缓存
# ============================================================
def load_cache():
    if not CACHE_FILE.exists():
        return {}
    with open(CACHE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_cache(cache):
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)

def get_cache_key(text, target_lang, mode, model, glossary):
    """生成缓存键（基于文本哈希 + 参数）"""
    content = f"{text}|{target_lang}|{mode}|{model}|{json.dumps(glossary, sort_keys=True)}"
    return hashlib.sha256(content.encode()).hexdigest()[:32]

def check_cache(cache_key):
    """检查缓存，命中返回结果，否则返回 None"""
    cache = load_cache()
    entry = cache.get(cache_key)
    if entry:
        return entry["result"]
    return None

def add_to_cache(cache_key, result):
    """添加缓存条目，维护 50 条 LRU 上限"""
    cache = load_cache()
    cache[cache_key] = {
        "result": result,
        "timestamp": datetime.now().isoformat(),
    }
    # LRU: 保留最近 50 条
    if len(cache) > 50:
        sorted_items = sorted(cache.items(), key=lambda x: x[1]["timestamp"])
        cache = dict(sorted_items[-50:])
    save_cache(cache)

# ============================================================
# 段落分隔符 & 智能段落合并
# ============================================================
PARA_SEP = "\n⏎⏎⏎\n"

def _is_paragraph_boundary(prev_line, curr_line):
    """判断两行之间是否为段落边界"""
    if not prev_line or not curr_line:
        return True
    prev = prev_line.rstrip()
    curr = curr_line.lstrip()
    # 上一行以句子结束标点结尾 → 大概率是新段落
    if prev and prev[-1] in '.!?。？！':
        return True
    # 下一行以大写开头（英文）→ 可能是新段落
    if curr and curr[0].isupper():
        return True
    # 上一行以连字符结尾 → 单词拆分，继续
    if prev and prev[-1] == '-':
        return False
    return False

def _merge_lines_into_paragraphs(text):
    """将 PDF 逐行文本合并为真实段落"""
    lines = text.split("\n")
    paragraphs = []
    current = ""

    for line in lines:
        stripped = line.strip()
        # 跳过页标记
        if stripped.startswith("--- 第") or stripped.startswith("--- Page"):
            continue
        # 空行 → 段落边界
        if not stripped:
            if current.strip():
                paragraphs.append(current.strip())
                current = ""
            continue

        if not current:
            current = stripped
        elif _is_paragraph_boundary(current, stripped):
            paragraphs.append(current.strip())
            current = stripped
        else:
            # 同行段落内拼接
            if current.rstrip()[-1] == '-':
                # 连字符断词：去掉 - 直接拼接
                current = current.rstrip()[:-1] + stripped
            else:
                current = current.rstrip() + " " + stripped

    if current.strip():
        paragraphs.append(current.strip())

    return paragraphs

def preprocess_for_translation(text):
    """预处理原文：合并行为段落，用分隔符标记"""
    paragraphs = _merge_lines_into_paragraphs(text)
    return PARA_SEP.join(paragraphs)

def clean_translated_text(text):
    """清理译文中的分块标记和无关内容"""
    import re
    # 移除 "--- 第 X/N 段 ---" 分块标记
    text = re.sub(r'\n*--- 第 \d+/\d+ 段 ---\n*', '\n', text)
    return text.strip()

def align_paragraphs(original_text, translated_text):
    """将原文和译文按分隔符拆分并对齐"""
    # 清理译文
    translated_text = clean_translated_text(translated_text)
    orig_paras = [p.strip() for p in original_text.split(PARA_SEP) if p.strip()]
    trans_paras = [p.strip() for p in translated_text.split(PARA_SEP) if p.strip()]

    # 如果译文分隔符丢失（段数不匹配），回退为整体输出
    if len(trans_paras) <= 1 and len(orig_paras) > 1:
        # AI 没有保留分隔符，将整段译文作为一个段落
        trans_paras = [translated_text.strip()]

    # 补齐到相同长度
    while len(trans_paras) < len(orig_paras):
        trans_paras.append("[翻译缺失]")

    pairs = []
    for i, orig in enumerate(orig_paras):
        trans = trans_paras[i] if i < len(trans_paras) else "[翻译缺失]"
        pairs.append((orig, trans))
    return pairs

# ============================================================
# API 调用（支持流式 + 非流式）
# ============================================================
def build_translation_prompt(text, target_lang, mode, glossary_prompt):
    """构建翻译提示词"""
    if mode == "full":
        if target_lang == "中文":
            return f"""{glossary_prompt}请将以下内容逐段翻译成中文。每段之间用「⏎⏎⏎」分隔。
重要：保持段落分隔符「⏎⏎⏎」不变，段落数量必须一致，不要合并或拆分段落。

原文：
{text}

中文翻译（保持⏎⏎⏎分隔符）："""
        elif target_lang == "English":
            return f"""{glossary_prompt}Please translate the following content paragraph by paragraph into English.
Separate each paragraph with 「⏎⏎⏎」.
IMPORTANT: Keep the 「⏎⏎⏎」 separators unchanged. Do NOT merge or split paragraphs.

Original text:
{text}

English translation (keep ⏎⏎⏎ separators):"""
        else:
            return f"""{glossary_prompt}请将以下内容逐段翻译成{target_lang}。每段之间用「⏎⏎⏎」分隔。
重要：保持分隔符不变，段落数量必须一致。

原文：
{text}

翻译（保持⏎⏎⏎分隔符）："""

    elif mode == "summary":
        if target_lang == "中文":
            return f"""请根据以下论文内容，输出：
1. 用中文写一份200字左右的摘要，概括核心观点
2. 提取5-10个关键英文术语，并给出对应中文解释
3. 用英文写一份100字左右的摘要

论文内容：
{text}

请按以下格式输出：
【中文摘要】
...
【关键术语】
1. term - 解释
2. term - 解释
【英文摘要】
..."""
        else:
            return f"""Please analyze the following paper content and output:
1. Write a 200-word abstract in English
2. Extract 5-10 key Chinese academic terms with English explanations
3. Write a 100-word abstract in Chinese

Paper content:
{text}

Please output in this format:
[English Abstract]
...
[Key Terms]
1. term - explanation
2. term - explanation
[Chinese Abstract]
..."""

    else:  # both
        if target_lang == "中文":
            return f"""{glossary_prompt}请对以下内容进行全面处理：
1. 完整翻译成中文
2. 写一份200字的中文摘要
3. 提取5-10个关键术语（中英文对照）

原文：
{text}

请按以下格式输出：
【全文翻译】
...
【摘要】
...
【关键术语】
1. term - 中文解释
2. term - 中文解释"""
        else:
            return f"""{glossary_prompt}Please process the following content comprehensively:
1. Complete translation into English
2. Write a 200-word English abstract
3. Extract 5-10 key terms (English-Chinese)

Original text:
{text}

Please output in this format:
[Full Translation]
...
[Abstract]
...
[Key Terms]
1. term - explanation
2. term - explanation"""


def call_dashscope(text, target_lang, mode, model, api_key, glossary_prompt=""):
    """调用 Qwen API 翻译（非流式）。返回 (result_text, was_interrupted)"""
    if not text or not text.strip():
        raise ValueError("提取内容为空")

    MAX_CHARS = 4000
    # full 模式预处理：插入段落分隔符
    if mode == "full":
        text = preprocess_for_translation(text)

    if len(text) > MAX_CHARS and mode == "full":
        return translate_long_text(text, target_lang, model, api_key, glossary_prompt)

    prompt = build_translation_prompt(text, target_lang, mode, glossary_prompt)

    response = Generation.call(
        model=model,
        api_key=api_key,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=4000,
        temperature=0.3,
    )

    if response.status_code == 200:
        return response.output.text, False
    else:
        raise Exception(f"API 调用失败: {response.code} - {response.message}")


def call_dashscope_stream(text, target_lang, mode, model, api_key, glossary_prompt=""):
    """调用 Qwen API 翻译（流式），生成器逐段返回文本。"""
    if mode == "full":
        text = preprocess_for_translation(text)
    prompt = build_translation_prompt(text, target_lang, mode, glossary_prompt)

    response = Generation.call(
        model=model,
        api_key=api_key,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=4000,
        temperature=0.3,
        stream=True,
    )

    for chunk in response:
        if chunk.output and chunk.output.text:
            yield chunk.output.text


def translate_long_text(text, target_lang, model, api_key, glossary_prompt, stop_checker=None):
    """分段翻译长文本。返回 (result_text, was_interrupted)"""
    text = preprocess_for_translation(text)
    paragraphs = text.split(PARA_SEP)
    chunks = []
    current_chunk = ""

    for para in paragraphs:
        if len(current_chunk) + len(para) < 3000:
            current_chunk += para + PARA_SEP
        else:
            if current_chunk:
                chunks.append(current_chunk.rstrip(PARA_SEP))
            current_chunk = para + PARA_SEP
    if current_chunk:
        chunks.append(current_chunk.rstrip(PARA_SEP))

    translated_chunks = []
    for i, chunk in enumerate(chunks):
        if stop_checker and stop_checker():
            return PARA_SEP.join(translated_chunks), True

        prompt = build_translation_prompt(chunk, target_lang, "full", glossary_prompt)

        try:
            response = Generation.call(
                model=model,
                api_key=api_key,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=3000,
                temperature=0.3,
            )
            if response.status_code == 200:
                translated_chunks.append(response.output.text)
            else:
                translated_chunks.append(f"[翻译错误: {response.code}]")
        except Exception as e:
            translated_chunks.append(f"[翻译错误: {str(e)}]")

    return PARA_SEP.join(translated_chunks), False


def translate_long_text_stream(text, target_lang, model, api_key, glossary_prompt, stop_checker=None):
    """分段翻译长文本（流式）。逐段翻译，每段内流式输出。"""
    text = preprocess_for_translation(text)
    paragraphs = text.split(PARA_SEP)
    chunks = []
    current_chunk = ""

    for para in paragraphs:
        if len(current_chunk) + len(para) < 3000:
            current_chunk += para + PARA_SEP
        else:
            if current_chunk:
                chunks.append(current_chunk.rstrip(PARA_SEP))
            current_chunk = para + PARA_SEP
    if current_chunk:
        chunks.append(current_chunk.rstrip(PARA_SEP))

    for i, chunk in enumerate(chunks):
        if stop_checker and stop_checker():
            yield "\n\n--- 翻译已停止 ---\n\n", True
            return

        # 发送段分隔符
        yield f"\n\n--- 第 {i+1}/{len(chunks)} 段 ---\n\n", False

        prompt = build_translation_prompt(chunk, target_lang, "full", glossary_prompt)

        try:
            response = Generation.call(
                model=model,
                api_key=api_key,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=3000,
                temperature=0.3,
                stream=True,
            )
            for chunk_resp in response:
                if stop_checker and stop_checker():
                    yield "\n\n--- 翻译已停止 ---\n\n", True
                    return
                if chunk_resp.output and chunk_resp.output.text:
                    yield chunk_resp.output.text, False
        except Exception as e:
            yield f"\n[翻译错误: {str(e)}]\n", False

    yield "", False  # 完成信号


# ============================================================
# 进度预估
# ============================================================
class ProgressEstimator:
    """基于滚动平均的进度预估器"""
    def __init__(self, total_chunks):
        self.total = total_chunks
        self.completed = 0
        self.times = []  # 最近 5 段的耗时

    def record(self, elapsed_seconds):
        self.completed += 1
        self.times.append(elapsed_seconds)
        if len(self.times) > 5:
            self.times.pop(0)

    def estimate_remaining(self):
        """返回预估剩余秒数"""
        if not self.times or self.completed >= self.total:
            return 0
        avg = sum(self.times) / len(self.times)
        remaining = self.total - self.completed
        return int(avg * remaining)

    def format_remaining(self):
        seconds = self.estimate_remaining()
        if seconds <= 0:
            return "即将完成"
        if seconds < 60:
            return f"约 {seconds} 秒"
        return f"约 {seconds // 60} 分 {seconds % 60} 秒"


# ============================================================
# PDF 图片提取
# ============================================================
def extract_pdf_images(uploaded_bytes, max_pages=50):
    """从 PDF 提取图片，返回 [{page, bytes, ext, width, height}, ...]"""
    images = []
    try:
        doc = fitz.open(stream=uploaded_bytes, filetype="pdf")
        pages_to_process = min(max_pages, len(doc))
        for page_num in range(pages_to_process):
            page = doc[page_num]
            image_list = page.get_images(full=True)
            for img in image_list:
                xref = img[0]
                try:
                    base_image = doc.extract_image(xref)
                    images.append({
                        "page": page_num + 1,
                        "bytes": base_image["image"],
                        "ext": base_image["ext"],
                        "width": base_image.get("width", 0),
                        "height": base_image.get("height", 0),
                    })
                except Exception:
                    continue  # 跳过无法提取的图片
        doc.close()
    except Exception:
        pass  # 图片提取失败不影响文本翻译
    return images


# ============================================================
# 公式识别（图片 → LaTeX）
# ============================================================
def is_formula_image(img):
    """启发式判断图片是否为数学公式（小尺寸、高宽比接近1的图片）"""
    w, h = img.get("width", 0), img.get("height", 0)
    size_bytes = len(img.get("bytes", b""))
    if w == 0 or h == 0:
        return False
    aspect = w / h if h > 0 else 0
    # 公式通常：小尺寸（< 500px）、不是极端的长条形、文件较小
    return (w < 500 and h < 200) or (0.5 < aspect < 15 and size_bytes < 50000)


def recognize_formulas(images, api_key):
    """将疑似公式的图片通过 Qwen-VL 转换为 LaTeX 格式"""
    formulas = []
    formula_images = [img for img in images if is_formula_image(img)]

    if not formula_images:
        return formulas

    for idx, img in enumerate(formula_images):
        try:
            b64 = base64.b64encode(img["bytes"]).decode("utf-8")
            data_uri = f"data:image/{img['ext']};base64,{b64}"

            from dashscope import MultiModalConversation
            response = MultiModalConversation.call(
                model="qwen-vl-plus",
                api_key=api_key,
                messages=[{
                    "role": "user",
                    "content": [
                        {"image": data_uri},
                        {"text": "请将图片中的数学公式转换为LaTeX格式。只输出LaTeX代码，不要任何解释。如果是普通图表而不是公式，请回复'NOT_FORMULA'。"}
                    ]
                }]
            )

            if response.status_code == 200:
                latex = response.output.choices[0].message.content[0]["text"]
                if latex.strip() and "NOT_FORMULA" not in latex:
                    formulas.append({
                        "page": img["page"],
                        "latex": latex.strip(),
                    })
        except Exception:
            continue  # 单张公式识别失败不阻断流程

    return formulas


# ============================================================
# Word / TXT 导出
# ============================================================
def _set_run_font(run, cn_font="宋体", en_font="Times New Roman", size=11):
    """设置 run 的中英文字体：中文用 cn_font，英文用 en_font"""
    run.font.size = Pt(size)
    run.font.name = en_font
    rPr = run._element.get_or_add_rPr()
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), en_font)
    rFonts.set(qn("w:hAnsi"), en_font)
    rFonts.set(qn("w:eastAsia"), cn_font)
    rFonts.set(qn("w:cs"), en_font)
    rPr.insert(0, rFonts)


def save_to_word(original_text, translated_text, summary="", terms="", filename="翻译结果.docx", images=None, formulas=None):
    """纯译文输出：中文宋体，英文 Times New Roman，附图片和公式"""
    doc = Document()

    # 设置默认段落样式
    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(11)
    style.element.get_or_add_rPr().append(_make_rFonts("Times New Roman", "宋体"))

    # 输出译文（清理分隔符）
    clean_text = translated_text.replace("⏎⏎⏎", "\n")
    for para_text in clean_text.split("\n"):
        if para_text.strip():
            p = doc.add_paragraph(para_text.strip())
            for run in p.runs:
                _set_run_font(run)

    # 图片
    if images:
        doc.add_paragraph()
        doc.add_heading("文档图片", level=2)
        for idx, img in enumerate(images):
            try:
                doc.add_paragraph(f"图片 {idx + 1}（第 {img['page']} 页）")
                image_stream = BytesIO(img["bytes"])
                w = min(img["width"] / 150, 5.5) if img["width"] else 5.0
                h = min(img["height"] / 150, 3.0) if img["height"] else 3.0
                doc.add_picture(image_stream, width=Inches(w), height=Inches(h))
            except Exception:
                doc.add_paragraph(f"[图片 {idx + 1} 无法插入]")

    # 公式
    if formulas:
        doc.add_paragraph()
        doc.add_heading("公式（LaTeX 格式）", level=2)
        for idx, f in enumerate(formulas):
            doc.add_paragraph(f"公式 {idx + 1}（第 {f['page']} 页）:")
            p = doc.add_paragraph(f["latex"])
            for run in p.runs:
                _set_run_font(run, cn_font="宋体", en_font="Times New Roman", size=10)

    filepath = str(RESULT_DIR / filename)
    doc.save(filepath)
    return filepath


def _make_rFonts(en_font, cn_font):
    """创建 w:rFonts 元素"""
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), en_font)
    rFonts.set(qn("w:hAnsi"), en_font)
    rFonts.set(qn("w:eastAsia"), cn_font)
    rFonts.set(qn("w:cs"), en_font)
    return rFonts


def save_partial_result(original_text, translated_text, interrupted_at, filename="部分翻译结果.docx", images=None):
    """纯译文输出（部分完成），中文宋体"""
    doc = Document()
    p = doc.add_paragraph(f"注意：翻译在 {interrupted_at} 被中断，以下为已完成部分")
    _set_run_font(p.runs[0]) if p.runs else None

    clean_text = translated_text.replace("⏎⏎⏎", "\n")
    for para_text in clean_text.split("\n"):
        if para_text.strip():
            p = doc.add_paragraph(para_text.strip())
            for run in p.runs:
                _set_run_font(run)

    if images:
        doc.add_paragraph()
        doc.add_heading("文档图片", level=2)
        for idx, img in enumerate(images):
            try:
                doc.add_paragraph(f"图片 {idx + 1}（第 {img['page']} 页）")
                image_stream = BytesIO(img["bytes"])
                w = min(img["width"] / 150, 5.5) if img["width"] else 5.0
                doc.add_picture(image_stream, width=Inches(w))
            except Exception:
                doc.add_paragraph(f"[图片 {idx + 1} 无法插入]")

    filepath = str(RESULT_DIR / filename)
    doc.save(filepath)
    return filepath


def save_to_txt(text, filename="翻译结果.txt"):
    with open(filename, "w", encoding="utf-8") as f:
        f.write(text)
    return filename


# ============================================================
# 历史记录
# ============================================================
def load_history():
    if not HISTORY_FILE.exists():
        return []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_history(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

def add_history_entry(entry):
    history = load_history()
    history.insert(0, entry)
    if len(history) > 50:
        history = history[:50]
    save_history(history)

def delete_history_entry(index):
    history = load_history()
    if 0 <= index < len(history):
        history.pop(index)
        save_history(history)
