"""translate_ai - PDF/DOCX/TXT/MD 智能翻译助手 (Streamlit UI)"""

import streamlit as st
import os
from datetime import datetime
from dotenv import load_dotenv

from translate_utils import (
    extract_text,
    extract_pdf_text,
    extract_pdf_images,
    recognize_formulas,
    ocr_pdf_text,
    call_dashscope,
    call_dashscope_stream,
    translate_long_text,
    translate_long_text_stream,
    ProgressEstimator,
    get_cache_key,
    check_cache,
    add_to_cache,
    load_cache,
    load_glossary,
    save_glossary,
    save_history,
    add_glossary_term,
    remove_glossary_term,
    get_glossary_prompt,
    load_history,
    add_history_entry,
    delete_history_entry,
    save_to_word,
    save_partial_result,
)

load_dotenv()
API_KEY = os.getenv("DASHSCOPE_API_KEY")

# ============================================================
# 页面配置
# ============================================================
st.set_page_config(page_title="Cc多功能翻译器", page_icon="🌍", layout="wide")

# ============================================================
# Session State 初始化
# ============================================================
defaults = {
    "stop_translation": False,
    "translation_result": "",
    "original_text": "",
    "summary": "",
    "terms": "",
    "current_filename": "",
    "current_mode": "",
    "current_model": "",
    "current_lang": "",
}
for key, val in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = val


def set_stop_flag():
    st.session_state.stop_translation = True


def reset_stop_flag():
    st.session_state.stop_translation = False


def is_stopped():
    return st.session_state.stop_translation


# ============================================================
# 侧边栏
# ============================================================
def render_sidebar():
    with st.sidebar:
        st.header("⚙️ 翻译设置")

        # ---- 基本设置 ----
        with st.expander("📋 基本设置", expanded=True):
            translate_mode = st.radio(
                "翻译模式",
                ["全文翻译", "智能摘要", "全文翻译+摘要"],
                index=0,
            )
            mode_map = {"全文翻译": "full", "智能摘要": "summary", "全文翻译+摘要": "both"}

            target_lang = st.selectbox(
                "目标语言",
                ["中文", "English", "日本語", "한국어",
                 "Français", "Deutsch", "Español",
                 "Português", "Русский", "العربية"],
                index=0,
            )

            model = st.selectbox(
                "AI 模型",
                ["qwen-turbo (快速)", "qwen-plus (均衡)", "qwen-max (高质量)"],
                index=1,
                help="turbo 速度快成本低；plus 均衡；max 质量最高但较慢",
            )
            model_map = {
                "qwen-turbo (快速)": "qwen-turbo",
                "qwen-plus (均衡)": "qwen-plus",
                "qwen-max (高质量)": "qwen-max",
            }

        # ---- 高级选项 ----
        with st.expander("🔧 高级选项", expanded=False):
            use_streaming = st.checkbox("流式输出", value=True, help="逐字显示翻译结果，实时查看进度")
            use_cache = st.checkbox("使用翻译缓存", value=True, help="避免重复翻译相同内容，节省 API 费用")
            enable_comparison = st.checkbox("双模型对比", value=False, help="同时使用两个模型翻译，对比质量")

            comparison_model = None
            if enable_comparison:
                comparison_model = st.selectbox(
                    "对比模型",
                    ["qwen-turbo (快速)", "qwen-plus (均衡)", "qwen-max (高质量)"],
                    index=0,
                    help="选择用于对比的第二个模型",
                )
                comparison_model = model_map[comparison_model]

        # ---- OCR 选项（动态显示） ----
        with st.expander("🔍 OCR 扫描件", expanded=False):
            force_ocr = st.checkbox("扫描件 / 图片型 PDF", value=False)
            ocr_lang = "chi_sim+eng"
            if force_ocr:
                ocr_lang_choice = st.selectbox(
                    "OCR 识别语言",
                    ["中文 + 英文", "仅英文", "仅中文"],
                    index=0,
                )
                ocr_lang_map = {"中文 + 英文": "chi_sim+eng", "仅英文": "eng", "仅中文": "chi_sim"}
                ocr_lang = ocr_lang_map[ocr_lang_choice]
                st.info("ℹ️ 首次使用需安装: `brew install tesseract tesseract-lang`")

            max_pages = st.slider("处理页数限制", 1, 100, 20)

        # ---- 术语库 ----
        with st.expander("📚 术语库管理", expanded=False):
            glossary = load_glossary()
            if glossary:
                st.caption(f"共 {len(glossary)} 条术语")
                for src, tgt in list(glossary.items())[:10]:
                    col_a, col_b = st.columns([3, 1])
                    with col_a:
                        st.text(f"{src} → {tgt}")
                    with col_b:
                        if st.button("🗑️", key=f"del_{src}", help=f"删除 {src}"):
                            remove_glossary_term(src)
                            st.rerun()
            else:
                st.caption("暂无术语，添加后可确保翻译一致性")

            with st.form("add_term", clear_on_submit=True):
                col1, col2 = st.columns(2)
                with col1:
                    new_src = st.text_input("原文术语", placeholder="例如: transformer")
                with col2:
                    new_tgt = st.text_input("译文", placeholder="例如: 编码器")
                if st.form_submit_button("➕ 添加术语", use_container_width=True):
                    if new_src.strip() and new_tgt.strip():
                        add_glossary_term(new_src, new_tgt)
                        st.rerun()

            if glossary and st.button("🗑️ 清空术语库", use_container_width=True):
                save_glossary({})
                st.rerun()

        # ---- API Key 状态 ----
        st.markdown("---")
        if not API_KEY:
            st.error("❌ 未配置 API Key！请在 .env 文件中添加 DASHSCOPE_API_KEY")
        else:
            st.success("✅ API Key 已配置")
            cache = load_cache()
            st.caption(f"缓存: {len(cache)} 条 | 历史: {len(load_history())} 条 | 术语: {len(load_glossary())} 条")

    return {
        "mode": mode_map[translate_mode],
        "mode_label": translate_mode,
        "target_lang": target_lang,
        "model": model_map[model],
        "use_streaming": use_streaming,
        "use_cache": use_cache,
        "enable_comparison": enable_comparison,
        "comparison_model": comparison_model,
        "force_ocr": force_ocr,
        "ocr_lang": ocr_lang,
        "max_pages": max_pages,
    }


# ============================================================
# 翻译处理逻辑
# ============================================================
def run_translation(original_text, config):
    """执行翻译（支持缓存、流式、对比、进度预估）"""
    glossary_prompt = get_glossary_prompt()
    mode = config["mode"]
    target_lang = config["target_lang"]
    model = config["model"]
    use_cache = config["use_cache"]
    use_streaming = config["use_streaming"]

    # 检查缓存
    cache_key = get_cache_key(original_text, target_lang, mode, model, load_glossary())
    if use_cache:
        cached = check_cache(cache_key)
        if cached:
            st.success("✅ 命中翻译缓存，跳过 API 调用")
            return cached, False

    # 长文本分段
    MAX_CHARS = 4000
    is_long = len(original_text) > MAX_CHARS and mode == "full"

    if use_streaming:
        # ---- 流式翻译 ----
        output_placeholder = st.empty()
        progress_bar = st.progress(0)
        progress_text = st.empty()
        full_text = ""

        if is_long:
            completed_text = ""
            segment_text = ""
            total_chunks = 0
            current_chunk = 0
            for chunk_text_stream, stopped in translate_long_text_stream(
                original_text, target_lang, model, API_KEY, glossary_prompt,
                stop_checker=is_stopped
            ):
                if stopped:
                    st.warning("⏹️ 翻译已停止")
                    return full_text, True
                if chunk_text_stream.startswith("\n\n--- 第"):
                    # 分块分隔符：归档上一块内容，显示进度
                    completed_text += segment_text
                    segment_text = ""
                    import re
                    m = re.search(r"第 (\d+)/(\d+) 段", chunk_text_stream)
                    if m:
                        current_chunk = int(m.group(1))
                        total_chunks = int(m.group(2))
                    progress_bar.progress(current_chunk / total_chunks if total_chunks else 0)
                    progress_text.text(f"进度: {current_chunk}/{total_chunks} 块")
                elif chunk_text_stream:
                    # 累积当前块的文本（API 每次返回完整的累积结果）
                    segment_text = chunk_text_stream
                full_text = completed_text + segment_text
                display = full_text.replace("⏎⏎⏎", "\n\n")
                output_placeholder.markdown(display)
        else:
            progress_text.text("🌊 流式翻译中...")
            for chunk in call_dashscope_stream(
                original_text, target_lang, mode, model, API_KEY, glossary_prompt
            ):
                full_text = chunk
                display = full_text.replace("⏎⏎⏎", "\n\n")
                output_placeholder.markdown(display)
                # 用文本长度占预估token数来估算进度
                progress_bar.progress(min(len(full_text) / max(len(original_text) * 2, 1), 0.99))

        progress_bar.progress(1.0)
        progress_text.text("✅ 翻译完成")
        result = full_text
        was_interrupted = False
    else:
        # ---- 非流式翻译 ----
        with st.spinner("翻译中，请稍候..."):
            if is_long:
                st.info(f"📚 文本较长（{len(original_text)} 字符），分段翻译中...")
                result, was_interrupted = translate_long_text(
                    original_text, target_lang, model, API_KEY, glossary_prompt,
                    stop_checker=is_stopped
                )
            else:
                try:
                    result, was_interrupted = call_dashscope(
                        original_text, target_lang, mode, model, API_KEY, glossary_prompt
                    )
                except Exception as e:
                    st.error(f"❌ 翻译失败: {str(e)}")
                    return "", False

    # 写入缓存
    if use_cache and not was_interrupted and result:
        add_to_cache(cache_key, result)

    return result, was_interrupted


def run_comparison(original_text, config, key_suffix=""):
    """双模型对比翻译"""
    model_a = config["model"]
    model_b = config["comparison_model"]
    target_lang = config["target_lang"]
    mode = config["mode"]
    glossary_prompt = get_glossary_prompt()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader(f"🤖 模型 A: {model_a}")
        t1_start = datetime.now()
        with st.spinner(f"{model_a} 翻译中..."):
            try:
                result_a, _ = call_dashscope(
                    original_text, target_lang, mode, model_a, API_KEY, glossary_prompt
                )
            except Exception as e:
                result_a = f"错误: {str(e)}"
        t1_elapsed = (datetime.now() - t1_start).total_seconds()
        st.text_area("模型 A 结果", result_a, height=350, key=f"cmp_a_{key_suffix}")
        st.caption(f"耗时: {t1_elapsed:.1f} 秒 | 长度: {len(result_a)} 字符")

    with col2:
        st.subheader(f"🤖 模型 B: {model_b}")
        t2_start = datetime.now()
        with st.spinner(f"{model_b} 翻译中..."):
            try:
                result_b, _ = call_dashscope(
                    original_text, target_lang, mode, model_b, API_KEY, glossary_prompt
                )
            except Exception as e:
                result_b = f"错误: {str(e)}"
        t2_elapsed = (datetime.now() - t2_start).total_seconds()
        st.text_area("模型 B 结果", result_b, height=350, key=f"cmp_b_{key_suffix}")
        st.caption(f"耗时: {t2_elapsed:.1f} 秒 | 长度: {len(result_b)} 字符")

    st.divider()
    st.caption(f"速度比: {model_a} {t1_elapsed:.1f}s vs {model_b} {t2_elapsed:.1f}s")


def parse_result(result, mode):
    """解析 API 返回结果，分离翻译/摘要/术语"""
    translated_text = ""
    summary = ""
    terms = ""

    if mode == "full":
        translated_text = result
    elif mode == "summary":
        summary = result
    else:
        # both 模式
        if "【全文翻译】" in result:
            parts = result.split("【全文翻译】")
            if len(parts) > 1:
                temp = parts[1]
                translated_text = temp.split("【摘要】")[0].strip() if "【摘要】" in temp else temp.strip()
        if "【摘要】" in result:
            parts = result.split("【摘要】")
            if len(parts) > 1:
                temp = parts[1]
                summary = temp.split("【关键术语】")[0].strip() if "【关键术语】" in temp else temp.strip()
        if "【关键术语】" in result:
            terms = result.split("【关键术语】")[1].strip()
        if not translated_text and not summary:
            translated_text = result

    return translated_text, summary, terms


# ============================================================
# 结果展示 & 导出
# ============================================================
def render_results(original_text, translated_text, summary, terms, config, key_suffix=""):
    """渲染翻译结果：左右对照 / 上下堆叠 / 仅翻译"""
    display_translation = translated_text.replace("⏎⏎⏎", "\n\n")

    view_mode = st.radio(
        "📐 视图模式",
        ["上下堆叠", "左右对照", "仅翻译"],
        index=0,
        horizontal=True,
        key=f"view_mode_{key_suffix}",
    )

    if view_mode == "左右对照":
        col_orig, col_trans = st.columns(2)
        with col_orig:
            st.subheader("📖 原文")
            st.text_area("原文", original_text, height=600, key=f"orig_view_{key_suffix}", label_visibility="collapsed", disabled=True)
        with col_trans:
            st.subheader("🌍 翻译（可编辑）")
            edited = st.text_area("翻译", display_translation, height=600, key=f"trans_view_{key_suffix}", label_visibility="collapsed")
    elif view_mode == "仅翻译":
        edited = st.text_area("翻译", display_translation, height=600, key=f"trans_only_{key_suffix}", label_visibility="collapsed")
    else:
        # 上下堆叠
        with st.expander("📖 查看原文", expanded=False):
            st.text(original_text)
        edited = st.text_area("翻译（可编辑）", display_translation, height=500, key=f"trans_stack_{key_suffix}")

    if summary:
        with st.expander("📝 摘要", expanded=True):
            st.write(summary)

    if terms:
        with st.expander("📚 关键术语", expanded=True):
            st.write(terms)

    return edited


def render_export_buttons(original_text, translated_text, summary, terms, images=None, formulas=None, display_text=None):
    """渲染导出按钮"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    word_file = save_to_word(original_text, translated_text, summary, terms, f"翻译结果_{timestamp}.docx", images=images, formulas=formulas)

    with open(word_file, "rb") as f:
        st.download_button(
            "📥 下载 Word 文档",
            data=f,
            file_name=os.path.basename(word_file),
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            use_container_width=True,
        )


# ============================================================
# 主区域 Tab
# ============================================================
def render_quick_translate(config):
    """小文本快速翻译：输入文本自动实时翻译，无需点击按钮"""
    st.header("⚡ 快速翻译")

    col_in, col_out = st.columns(2)

    with col_in:
        input_text = st.text_area(
            "输入文本",
            placeholder="在此输入要翻译的文字，自动实时翻译...",
            height=200,
            key="quick_input",
        )
        char_count = len(input_text)
        if char_count > 1000:
            st.caption(f"字符数: {char_count} ⚠️ 文本较长，建议使用下方文件翻译")
        else:
            st.caption(f"字符数: {char_count}")

    last_input = st.session_state.get("last_quick_input", "")
    cached_result = st.session_state.get("quick_result", "")

    # 输入被清空时提前清理
    if not input_text.strip() and last_input:
        st.session_state.quick_result = ""
        st.session_state.pop("last_quick_input", None)
        cached_result = ""

    # 在渲染 widget 之前把缓存结果写入 quick_output
    st.session_state.quick_output = cached_result
    with col_out:
        st.text_area("翻译结果", height=200, key="quick_output")

    # 自动翻译：输入变更时触发
    if input_text.strip() and input_text != last_input:
        glossary_prompt = get_glossary_prompt()
        full_text = ""
        try:
            for chunk in call_dashscope_stream(
                input_text, config["target_lang"], config["mode"], config["model"],
                API_KEY, glossary_prompt
            ):
                full_text = chunk
            st.session_state.quick_result = full_text
            st.session_state.last_quick_input = input_text
            st.rerun()
        except Exception as e:
            st.error(f"翻译失败: {e}")

    st.divider()


def render_translate_tab(config):
    """Tab 1: 翻译"""
    render_quick_translate(config)
    st.header("📁 上传文件")

    # 多文件上传
    uploaded_files = st.file_uploader(
        "支持 PDF / DOCX / TXT / MD 文件",
        type=["pdf", "docx", "txt", "md"],
        accept_multiple_files=True,
        help="可同时上传多个文件进行批量翻译",
    )

    if not uploaded_files:
        st.info("👆 上传文件开始翻译")
        return

    # 显示已上传文件列表
    file_names = [f.name for f in uploaded_files]
    st.caption(f"已上传 {len(uploaded_files)} 个文件: {', '.join(file_names)}")

    # 操作按钮
    c1, c2 = st.columns(2)
    with c1:
        start_btn = st.button("🚀 开始翻译", type="primary", use_container_width=True)
    with c2:
        stop_btn = st.button("⏹️ 停止翻译", use_container_width=True)

    if stop_btn:
        set_stop_flag()
        st.warning("⏹️ 正在停止...")

    # 检查是否有缓存结果（用户切换视图模式时需要重新渲染）
    has_cached = (
        "translation_result" in st.session_state
        and st.session_state.get("translation_result")
    )
    if not start_btn:
        if has_cached:
            cached_display = render_results(
                st.session_state.get("original_text", ""),
                st.session_state.get("translation_result", ""),
                st.session_state.get("summary", ""),
                st.session_state.get("terms", ""),
                config,
                key_suffix="cached",
            )
            cached_images = st.session_state.get("cached_images", [])
            if cached_images:
                with st.expander(f"🖼️ 文档图片（共 {len(cached_images)} 张）", expanded=False):
                    for row_start in range(0, len(cached_images), 2):
                        row_images = cached_images[row_start:row_start + 2]
                        img_cols = st.columns(2)
                        for j, img in enumerate(row_images):
                            with img_cols[j]:
                                st.image(img["bytes"], caption=f"图 {row_start + j + 1}（第 {img['page']} 页）", use_container_width=True)
            cached_formulas = st.session_state.get("cached_formulas", [])
            if cached_formulas:
                with st.expander(f"📐 公式（LaTeX，共 {len(cached_formulas)} 个）", expanded=True):
                    for idx, f in enumerate(cached_formulas):
                        st.caption(f"公式 {idx + 1}（第 {f['page']} 页）")
                        st.code(f["latex"], language="latex")
            st.divider()
            st.markdown("#### 💾 导出文件")
            render_export_buttons(
                st.session_state.get("original_text", ""),
                st.session_state.get("translation_result", ""),
                st.session_state.get("summary", ""),
                st.session_state.get("terms", ""),
                st.session_state.get("cached_images", []),
                st.session_state.get("cached_formulas", []),
                cached_display,
            )
        return

    reset_stop_flag()

    # 逐个处理文件
    for file_idx, uploaded_file in enumerate(uploaded_files):
        if is_stopped():
            st.warning("⏹️ 批量翻译已停止")
            break

        filename = uploaded_file.name
        file_ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

        if len(uploaded_files) > 1:
            st.divider()
            st.subheader(f"📄 [{file_idx + 1}/{len(uploaded_files)}] {filename}")

        # 步骤 1: 提取文本
        progress = st.empty()
        progress.info(f"📖 正在提取 {filename} 的文本...")

        try:
            if file_ext == "pdf":
                uploaded_bytes = uploaded_file.read()
                if config["force_ocr"]:
                    st.info("🔍 OCR 模式识别中...")
                    original_text = ocr_pdf_text(uploaded_bytes, config["max_pages"], config["ocr_lang"])
                else:
                    original_text, warning = extract_pdf_text(
                        uploaded_bytes, config["max_pages"], False, config["ocr_lang"]
                    )
                    if warning:
                        st.warning(warning)
                # 提取 PDF 图片
                images = extract_pdf_images(uploaded_bytes, config["max_pages"])
                # 识别公式（小图片 → LaTeX）
                with st.spinner("🔢 正在识别公式..."):
                    formulas = recognize_formulas(images, API_KEY) if images else []
            else:
                original_text, warning = extract_text(uploaded_file, config["max_pages"])
                images = []
                formulas = []

            if not original_text or not original_text.strip():
                st.error(f"❌ 无法从 {filename} 提取文本，跳过此文件")
                continue

            parts = [f"✅ 提取成功: {len(original_text)} 字符"]
            if images:
                parts.append(f"🖼️ {len(images)} 张图片")
            if formulas:
                parts.append(f"📐 {len(formulas)} 个公式")
            st.success(" | ".join(parts))
            progress.empty()

            # 步骤 2: 翻译
            if config["enable_comparison"] and not (len(uploaded_files) > 1):
                run_comparison(original_text, config, key_suffix=str(file_idx))
            else:
                if config["enable_comparison"] and len(uploaded_files) > 1:
                    st.warning("⚠️ 批量模式下不支持双模型对比，使用单模型翻译")

                result, was_interrupted = run_translation(original_text, config)

                if was_interrupted:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    partial_file = save_partial_result(
                        original_text, result, datetime.now().strftime("%H:%M:%S"),
                        f"部分翻译_{timestamp}.docx",
                        images=images,
                    )
                    with open(partial_file, "rb") as f:
                        st.download_button("📥 下载部分结果", data=f, file_name=partial_file)
                    continue

                # 解析结果
                translated_text, summary, terms = parse_result(result, config["mode"])

                # 保存到 session state
                st.session_state.translation_result = translated_text
                st.session_state.original_text = original_text
                st.session_state.summary = summary
                st.session_state.terms = terms
                st.session_state.current_filename = filename
                st.session_state.current_mode = config["mode"]
                st.session_state.current_model = config["model"]
                st.session_state.current_lang = config["target_lang"]
                st.session_state.cached_images = images
                st.session_state.cached_formulas = formulas

                # 显示结果（清理分隔符）
                display_text = render_results(original_text, translated_text, summary, terms, config,
                                             key_suffix=str(file_idx))

                # 显示提取的图片
                if images:
                    with st.expander(f"🖼️ 文档图片（共 {len(images)} 张）", expanded=False):
                        cols_per_row = 2
                        for row_start in range(0, len(images), cols_per_row):
                            row_images = images[row_start:row_start + cols_per_row]
                            img_cols = st.columns(cols_per_row)
                            for j, img in enumerate(row_images):
                                with img_cols[j]:
                                    st.image(
                                        img["bytes"],
                                        caption=f"图 {row_start + j + 1}（第 {img['page']} 页）",
                                        use_container_width=True,
                                    )

                # 显示公式
                if formulas:
                    with st.expander(f"📐 公式（LaTeX，共 {len(formulas)} 个）", expanded=True):
                        for idx, f in enumerate(formulas):
                            st.caption(f"公式 {idx + 1}（第 {f['page']} 页）")
                            st.code(f["latex"], language="latex")

                # 导出（Word 用原始译文保证对齐，TXT 用编辑后版本）
                st.divider()
                st.markdown("#### 💾 导出文件")
                render_export_buttons(original_text, translated_text, summary, terms, images, formulas, display_text)

                # 写入历史记录
                add_history_entry({
                    "timestamp": datetime.now().isoformat(),
                    "filename": filename,
                    "original_text": original_text[:2000],
                    "translated_text": translated_text[:2000],
                    "summary": summary[:1000] if summary else "",
                    "terms": terms[:500] if terms else "",
                    "model": config["model"],
                    "target_lang": config["target_lang"],
                    "mode": config["mode"],
                })

                st.balloons()

        except Exception as e:
            st.error(f"❌ 处理 {filename} 失败: {str(e)}")


def render_history_tab():
    """Tab 2: 历史记录"""
    st.header("📋 翻译历史")

    history = load_history()
    if not history:
        st.info("暂无翻译记录，上传文件翻译后会自动保存")
        return

    if st.button("🗑️ 清空全部历史", type="secondary"):
        save_history([])
        st.rerun()

    for i, entry in enumerate(history):
        ts = entry.get("timestamp", "")[:19]
        with st.expander(f"[{ts}] {entry.get('filename', '未知文件')} — {entry.get('target_lang', '')} | {entry.get('model', '')}", expanded=False):
            col_info, col_action = st.columns([3, 1])
            with col_info:
                st.caption(f"模式: {entry.get('mode', '')} | 模型: {entry.get('model', '')} | 目标语言: {entry.get('target_lang', '')}")
            with col_action:
                if st.button("🗑️ 删除", key=f"hist_del_{i}"):
                    delete_history_entry(i)
                    st.rerun()

            if entry.get("original_text"):
                with st.expander("📖 原文（前 2000 字符）", expanded=False):
                    st.text(entry["original_text"])
            if entry.get("translated_text"):
                with st.expander("🌍 翻译（前 2000 字符）", expanded=False):
                    st.text(entry["translated_text"])
            if entry.get("summary"):
                with st.expander("📝 摘要", expanded=False):
                    st.write(entry["summary"])


# ============================================================
# 主入口
# ============================================================
def main():
    reset_stop_flag()

    st.title("🌍 智能翻译助手")
    st.markdown("上传 PDF / DOCX / TXT / MD 文件，一键翻译 + 摘要 + 术语提取，支持流式输出和批量处理")
    st.markdown("---")

    config = render_sidebar()

    tab1, tab2 = st.tabs(["📝 翻译", "📋 历史记录"])

    with tab1:
        render_translate_tab(config)

    with tab2:
        render_history_tab()

    st.caption(f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    main()
