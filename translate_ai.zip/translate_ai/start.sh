#!/bin/bash
cd "$(dirname "$0")"
streamlit run translate_ai.py
