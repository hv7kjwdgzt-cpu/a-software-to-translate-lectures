# Cc多功能翻译器

基于 Streamlit + 阿里通义千问 Qwen API 的智能翻译桌面工具，支持多格式文件翻译、实时短文本翻译、术语库管理、批量处理等功能。

## 功能亮点

- **实时短文本翻译**：顶部双文本框，输入即翻译，无需点击任何按钮
- **多格式文件翻译**：PDF / DOCX / TXT / MD 文件上传翻译
- **AI 翻译引擎**：调用 Qwen API（DashScope），高质量中英互译及多语言翻译
- **流式输出**：逐字实时显示翻译结果，显示进度条
- **术语库**：自定义术语翻译对照表，确保学术/专业翻译一致性
- **翻译缓存**：自动缓存翻译结果，重复内容不重复调用 API，节省费用
- **双模型对比**：同时使用两个 Qwen 模型翻译，直观对比质量与速度
- **批量翻译**：一次上传多个文件，顺序处理，独立下载
- **智能摘要**：自动生成文章摘要和关键术语提取
- **公式识别**：自动识别 PDF 中的数学公式并转换为 LaTeX
- **OCR 扫描件**：支持扫描件/图片型 PDF 的文字识别
- **三种视图模式**：左右对照 / 上下堆叠 / 仅翻译，独立滚动对照阅读
- **可编辑导出**：翻译结果可直接编辑后导出 Word 文档
- **历史记录**：保存翻译历史，支持查看和删除
- **中断保存**：翻译过程中可随时停止，已翻译部分自动保存
- **多语言**：支持中文、English、日本語、한국어、Français、Deutsch、Español、Português、Русский、العربية

## 快速开始

### 1. 克隆项目

```bash
git clone https://github.com/HSGHYJ/translate_ai
cd translate_ai
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 安装 Tesseract（OCR 功能需要，可选）

```bash
# macOS
brew install tesseract tesseract-lang

# Ubuntu/Debian
sudo apt install tesseract-ocr tesseract-ocr-chi-sim tesseract-ocr-chi-tra

# Windows
# 下载安装: https://github.com/UB-Mannheim/tesseract/wiki
```

### 4. 配置 API Key

在项目根目录创建 `.env` 文件：

```
DASHSCOPE_API_KEY=你的API密钥
```

> 获取地址：[阿里云 DashScope 控制台](https://dashscope.aliyun.com/)

### 5. 启动

**方式一：一键启动**

```bash
./start.sh
```

**方式二：命令行启动**

```bash
streamlit run translate_ai.py
```

浏览器访问 `http://localhost:8501`

## 使用指南

### 快速翻译（短文本）

- 页面顶部左右双文本框
- 左侧输入文字，右侧自动实时显示翻译结果
- 无需点击任何按钮，输入即翻译
- 建议 1000 字符以内使用此模式

### 文件翻译

1. 在侧边栏选择翻译模式、目标语言和 AI 模型
2. 添加自定义术语（可选，确保专业术语翻译一致）
3. 上传文件（支持 PDF / DOCX / TXT / MD）
4. 点击「开始翻译」
5. 如需中途停止，点击「停止翻译」按钮
6. 在视图模式中切换左右对照、上下堆叠或仅翻译
7. 编辑翻译结果后下载 Word 文档

### 视图模式

| 模式 | 说明 |
|------|------|
| 上下堆叠 | 原文折叠在上方，翻译在下方 |
| 左右对照 | 左原文右翻译，独立滚动对照 |
| 仅翻译 | 只显示翻译结果，适合纯阅读 |

### 术语库

在侧边栏「术语库管理」中添加术语对照，例如：
- `transformer → 编码器`
- `attention → 注意力机制`

翻译时这些术语会被注入到 prompt 中，确保翻译一致性。

### 导出

翻译结果在 `result/` 目录下，格式为 Word (.docx)：
- 中文使用宋体
- 英文使用 Times New Roman
- 公式以 LaTeX 格式附在文档末尾

## 项目结构

```
translate_ai/
├── translate_ai.py            # Streamlit UI 主界面
├── translate_utils.py         # 业务逻辑（提取、翻译、缓存、导出）
├── start.sh                   # 一键启动脚本
├── .streamlit/
│   └── config.toml            # UI 主题配置
├── data/                      # 持久化数据
│   ├── glossary.json           # 术语库
│   ├── translation_cache.json  # 翻译缓存
│   └── translation_history.json # 翻译历史
├── result/                    # 翻译结果导出
├── .env                       # API Key（已 gitignore）
├── .gitignore
├── requirements.txt
├── README.md
└── prd.md                     # 产品需求文档
```

## 技术栈

| 组件 | 技术 |
|------|------|
| Web UI | Streamlit |
| AI 翻译 | Qwen (阿里通义千问)，DashScope SDK |
| 公式识别 | Qwen-VL 多模态模型 |
| PDF 文本 | pdfplumber |
| PDF 图片 | PyMuPDF (fitz) |
| OCR 识别 | Tesseract + pdf2image + pytesseract |
| 文档导出 | python-docx |
| 数据持久化 | JSON |

## 安全提示

- `.env` 文件已被 `.gitignore` 忽略，请勿提交 API Key
- 若之前已提交过密钥，建议在阿里云后台**轮换密钥**
- 翻译缓存和术语库存放在本地，不向第三方传输数据
